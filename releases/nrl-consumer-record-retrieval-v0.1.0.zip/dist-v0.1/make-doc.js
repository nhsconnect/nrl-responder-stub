"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const marked_1 = __importDefault(require("marked"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
marked_1.default.setOptions({
    smartypants: true,
});
const md = fs_1.default.readFileSync(path_1.default.join(__dirname, 'src', 'README.md'), 'utf8');
const htmlTemplate = fs_1.default.readFileSync(path_1.default.join(__dirname, 'src', 'README.template.html'), 'utf8');
const html = htmlTemplate.replace('{{md}}', marked_1.default(md));
fs_1.default.writeFileSync(path_1.default.join(__dirname, 'src', 'README.html'), html);
