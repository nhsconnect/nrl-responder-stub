"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("./config"));
const { pathFileMapping, endpointFormat } = config_1.default;
const getSuccessEndpointForFileExt = (ext) => {
    const endpoint = Object.keys(pathFileMapping)
        .find(key => pathFileMapping[key].endsWith(`.${ext}`));
    if (!endpoint) {
        throw new TypeError(`config.pathFileMapping must contain an endpoint for ${ext} filetype`);
    }
    return endpointFormat === 'local' ? encodeURIComponent(endpoint) : endpoint;
};
const guidedTestPlan = [
    {
        name: 'PDF retrieval',
        endpoint: getSuccessEndpointForFileExt('pdf'),
        expect: {
            responseCode: 200,
            validations: true,
        },
    },
    {
        name: 'JSON retrieval',
        endpoint: getSuccessEndpointForFileExt('json'),
        expect: {
            responseCode: 200,
            validations: ['1', '2']
        },
    },
    {
        name: 'Not found',
        endpoint: 'INVALID_ENDPOINT',
        expect: {
            responseCode: 400,
            validations: [],
        },
    },
];
exports.default = guidedTestPlan;
