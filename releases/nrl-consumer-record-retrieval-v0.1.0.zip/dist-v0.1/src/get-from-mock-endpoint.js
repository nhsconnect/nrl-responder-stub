"use strict";
/**
 * Handles all GET requests to any non-root path
 * (or specified paths only in guided mode)
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const run_validations_1 = __importDefault(require("./run-validations"));
const validations_1 = __importDefault(require("./validations"));
const set_mime_type_1 = __importDefault(require("./set-mime-type"));
const ids_1 = require("./ids");
const http_status_1 = __importDefault(require("./http-status"));
const config_1 = __importDefault(require("./config"));
const logs_1 = require("./logs");
const { pathFileMapping, endpointFormat, secureMode, } = config_1.default;
const VALIDATION_IDS = {
    responseCode: `${ids_1.globalId()}`,
};
const getFromMockEndpoint = (request, response, next, testCase) => {
    const validations = new validations_1.default(request, response);
    validations
        .add(VALIDATION_IDS.responseCode, 'Request returns 2XX response code')
        .setFailureState(false); // initialize to success
    const fail = (response, code, message) => {
        validations
            .find(VALIDATION_IDS.responseCode)
            .setFailureState(`Request failed with status ${code}: ${JSON.stringify(message)}`);
        response
            .status(code)
            .send(message);
        return next();
    };
    if (secureMode) {
        const certificate = request.connection.getPeerCertificate();
        const isAuthorised = request.client.authorized;
        if (!isAuthorised) {
            if (certificate.subject) {
                return fail(response, http_status_1.default.Forbidden, {
                    certificate: {
                        subject: certificate.subject.CN || null,
                        issuer: certificate.issuer.CN || null,
                    },
                    message: 'Unauthorized client certificate',
                });
            }
            else {
                return fail(response, http_status_1.default.Unauthorized, {
                    certificate: null,
                    message: 'No client certificate',
                });
            }
        }
    }
    // `path` var is already in use by node's `path` module
    const $path = request.url.slice(1);
    // console.log(testCase); // TODO - awaiting guided mode
    if (endpointFormat === 'local' && $path.includes('/')) {
        response
            .status(http_status_1.default.BadRequest)
            .send('Provider URL must be percent-encoded (cannot contain unescaped forward-slashes)');
        return next();
    }
    run_validations_1.default(validations);
    // logging
    response.on('finish', () => {
        const logEntry = logs_1.buildLogEntry(request, response, validations);
        logs_1.writeLog(logEntry);
    });
    if (response.headersSent) {
        return next();
    }
    if (validations.list().some(validation => validation.success === false)) {
        const data = {
            failures: validations.listSerializable().filter(validation => validation.success === false)
        };
        return fail(response, http_status_1.default.BadRequest, data);
    }
    let url;
    if (endpointFormat === 'local') {
        try {
            url = decodeURIComponent($path);
        }
        catch (_a) {
            return fail(response, http_status_1.default.BadRequest, `${$path} cannot be percent-decoded`);
        }
        try {
            new URL(url);
        }
        catch (_b) {
            return fail(response, http_status_1.default.BadRequest, `${url} is not a valid URL`);
        }
    }
    const urlOrPath = url || $path;
    const fileName = pathFileMapping[urlOrPath];
    if (!fileName) {
        return fail(response, http_status_1.default.NotFound, `A filename corresponding to path ${urlOrPath} must exist in pathFileMapping in configuration`);
    }
    const filePath = path_1.default.join(__dirname, 'responses', fileName);
    if (!fs_1.default.existsSync(filePath)) {
        return fail(response, http_status_1.default.NotFound, `fileName ${fileName} must exist as a file in the responses folder`);
    }
    set_mime_type_1.default(request, response);
    return response.sendFile(filePath, next); // `next` fn must be in callback - see https://stackoverflow.com/a/33767854
};
exports.default = getFromMockEndpoint;
