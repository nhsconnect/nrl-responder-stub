"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("./config"));
const { useFhirMimeTypes, explicitlySetUtf8 } = config_1.default;
const FILE_FORMATS = {
    json: {
        extension: 'json',
        baseMimeType: 'application/json',
        fhirMimeType: 'application/fhir+json',
    },
    xml: {
        extension: 'xml',
        baseMimeType: 'application/xml',
        fhirMimeType: 'application/fhir+xml',
    }
};
exports.default = (request, response) => {
    var _a;
    const extension = (_a = request.url.match(/\.(\w+)$/)) === null || _a === void 0 ? void 0 : _a[1]; // percent-encoding doesn't affect "."
    const fileFormat = extension && FILE_FORMATS[extension];
    if (fileFormat) {
        let contentType = fileFormat[useFhirMimeTypes ? 'fhirMimeType' : 'baseMimeType'];
        if (explicitlySetUtf8) {
            contentType += ';charset=utf-8';
        }
        response.type(contentType);
    }
};
