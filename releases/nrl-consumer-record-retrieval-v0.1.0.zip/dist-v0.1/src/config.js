"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_user_1 = __importDefault(require("./config.user"));
const config_defaults_1 = __importDefault(require("./config.defaults"));
Object.entries(config_user_1.default).forEach(([key, val]) => {
    config_defaults_1.default[key] = val;
});
if (typeof config_defaults_1.default.secureMode === 'undefined') {
    config_defaults_1.default.secureMode = !!(config_defaults_1.default.sslCACert && config_defaults_1.default.sslServerKey && config_defaults_1.default.sslServerCert);
}
exports.default = config_defaults_1.default;
