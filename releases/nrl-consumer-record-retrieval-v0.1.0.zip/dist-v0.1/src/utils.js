"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const normaliseRootEndpoint = (str) => {
    const noSlash = str.startsWith('/')
        ? str.slice(1)
        : str;
    return {
        noSlash,
        withSlash: `/${noSlash}`
    };
};
exports.normaliseRootEndpoint = normaliseRootEndpoint;
