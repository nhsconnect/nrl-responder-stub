"use strict";
/**
 * Converts reports from JSON => pretty-printed HTML
 *
 * HTML is generated using handlebars, based on the
 * `static/report-template.html` template.
 *
 * If -f or --input-file argument passed, selects file from `reports` dir based
 * on that filename.
 *
 * Else, selects the most recent JSON report (based on ISO-formatted dates in
 * filenames).
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const handlebars_1 = __importDefault(require("handlebars"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const dirName = path_1.default.join(__dirname, 'reports');
const flagIdx = process.argv
    .findIndex(arg => ['-f', '--input-file'].includes(arg)) + 1;
// index is -1 if not found; adding 1 yields 0 if not found, else the next arg
const arg = flagIdx && process.argv[flagIdx]; // short-circuits if 0
const fileName = arg || fs_1.default.readdirSync(dirName) // 0 is falsy
    .filter((fileName) => fileName.endsWith('.json'))
    .sort()
    .pop();
if (!fileName) {
    process.exit(1);
}
const data = JSON.parse(fs_1.default.readFileSync(path_1.default.join(dirName, fileName), 'utf8'));
const formatHeaders = (headers) => {
    const formattedHeaders = [];
    Object.entries(headers).forEach(([$name, value]) => {
        const name = $name.replace(/\b[a-z]/g, match => match.toUpperCase()).replace(/id\b/, 'Id');
        formattedHeaders.push({ name, value });
    });
    return formattedHeaders;
};
const splitNumbers = (str) => str.split(/(\d+(?:\.\d+)?)/).map((el, idx) => {
    return idx % 2 ? parseFloat(el) : el;
});
const sortValidations = (validationA, validationB) => {
    // sort validations by name in lexicographical order (e.g. A9, A10, B1, B2...)
    const [idA, idB] = [validationA, validationB].map(validation => validation.validationId);
    const [splitIdA, splitIdB] = [idA, idB].map(splitNumbers);
    while ([splitIdA, splitIdB].every(arr => arr.length)) {
        const [currentA, currentB] = [splitIdA, splitIdB]
            .map(arr => { var _a; return _a = arr.shift(), (_a !== null && _a !== void 0 ? _a : -Infinity); });
        if (currentA !== currentB) {
            return currentA > currentB ? 1 : -1;
        }
    }
    return 0;
};
data.metaJson = JSON.stringify(data.meta, null, 4);
data.logs.forEach((log) => {
    log.request.headers = formatHeaders(log.request.headers);
    log.response.headers = formatHeaders(log.response.headers);
    const [all, passed, failed, notRun] = [
        () => true,
        (validation) => validation.hasRun && validation.success,
        (validation) => validation.hasRun && !validation.success,
        (validation) => !validation.hasRun,
    ].map(filterFn => log.validations.filter(filterFn).sort(sortValidations));
    log.validations = { all, passed, failed, notRun };
});
fs_1.default.readFile(path_1.default.join(__dirname, 'static/report-template.html'), 'utf-8', (error, source) => {
    const template = handlebars_1.default.compile(source);
    const html = template(data);
    fs_1.default.writeFileSync(path_1.default.join(dirName, 'html', fileName.replace(/\.json$/, '.html')), html);
});
