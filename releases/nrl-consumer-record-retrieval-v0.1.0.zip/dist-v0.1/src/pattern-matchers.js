"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _hex = '[0-9a-fA-F]';
const _asid = '\\d{12}';
const _odsCode = '[0-9a-zA-Z]{3,5}';
const _pipe = '(?:%7[cC]|\\|)'; // agnostic as to percent encoding
const _uuidMatcher = new RegExp(`^${_hex}{8}-${_hex}{4}-${_hex}{4}-${_hex}{4}-${_hex}{12}$`);
const _asidMatcher = new RegExp(`^${_asid}$`);
const _requestingSystemMatcher = new RegExp(`^https://fhir\\.nhs\\.uk/Id/accredited-system${_pipe}${_asid}$`);
const _requestingOrganizationMatcher = new RegExp(`^https://fhir\\.nhs\\.uk/Id/ods-organization-code${_pipe}${_odsCode}$`);
const createMatcher = (regex) => (str) => regex.test(str);
const isUuid = createMatcher(_uuidMatcher);
exports.isUuid = isUuid;
const isAsid = createMatcher(_asidMatcher);
exports.isAsid = isAsid;
const isRequestingSystem = createMatcher(_requestingSystemMatcher);
exports.isRequestingSystem = isRequestingSystem;
const isRequestingOrganization = createMatcher(_requestingOrganizationMatcher);
exports.isRequestingOrganization = isRequestingOrganization;
