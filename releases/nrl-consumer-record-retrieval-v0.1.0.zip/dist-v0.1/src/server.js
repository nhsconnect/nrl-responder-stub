"use strict";
/**
 * Handles all app routing
 *
 * This works slightly differently in `guided` vs. `exploratory mode:
 *
 * In `guided` mode, endpoints are registered dynamically, using a promise
 * chain wherein each promise resolves after the endpoint in question is hit,
 * triggering the next endpoint to be registered. Upon hitting each endpoint,
 * requests are passed to the logic in './get-from-mock-endpoint', running only
 * the relevant validations as configured in the test plan. The endpoints and
 * config in question can be found in `./guided-test-plan`.
 *
 * In `exploratory` mode, all requests are simply passed on to the logic in
 * './get-from-mock-endpoint', running all validations in sequence.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const chalk_1 = __importDefault(require("chalk"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const http_status_1 = __importDefault(require("./http-status"));
const config_1 = __importDefault(require("./config"));
const get_from_mock_endpoint_1 = __importDefault(require("./get-from-mock-endpoint"));
const guided_test_plan_1 = __importDefault(require("./guided-test-plan"));
const logs_1 = require("./logs");
const utils_1 = require("./utils");
const https_1 = __importDefault(require("https"));
const { port, logBodyMaxLength, reportOutputs, mode, secureMode, sslServerCert, sslServerKey, } = config_1.default;
const app = express_1.default();
const truncate = (str, maxLen) => {
    return str.length <= maxLen ? str : str.slice(0, maxLen) + '...';
};
const start = () => {
    app.use(function (_request, response, next) {
        // populate `response.body` on `sendFile`, for logging purposes
        // this allows output reports to include snippets of the response body
        const sendFile = response.sendFile;
        response.sendFile = function (path, fn) {
            const body = fs_1.default.readFileSync(path, 'utf8');
            switch (logBodyMaxLength) {
                case -1:
                    response.body = body;
                    break;
                case 0:
                    // no-op - body not added to log
                    break;
                default:
                    response.body = truncate(body, logBodyMaxLength);
                    break;
            }
            sendFile.call(this, path, fn);
        };
        return next();
    });
    // prevent unnecessary console errors if viewed in browser
    app.get('/favicon.ico', (_request, response) => response.sendStatus(http_status_1.default.NoContent));
    app.get('/', (_request, response) => {
        // serve user docs at app root
        // this is generated from src/README.md during build
        return response.sendFile(path_1.default.join(__dirname, 'README.html'));
    });
    if (mode === 'guided') {
        (async () => {
            await guided_test_plan_1.default.reduce(async (promiseChain, testCase) => {
                await promiseChain;
                const endpoint = utils_1.normaliseRootEndpoint(testCase.endpoint).withSlash;
                const nextPromise = new Promise((resolve, _reject) => {
                    console.log(`\nHit endpoint ${chalk_1.default.cyan.bold(endpoint)}.`);
                    let hasRun = false;
                    app.get(endpoint, (request, response, next) => {
                        if (!hasRun) {
                            hasRun = true;
                            get_from_mock_endpoint_1.default(request, response, next, testCase);
                            resolve(); // proceed to next promise in the chain
                        }
                        else {
                            next();
                        }
                    });
                });
                return nextPromise;
            }, Promise.resolve()); // initial value for `reduce` is a resolved promise, initiating the promise chain
            console.log('All tests completed.');
            process.exit();
        })();
    }
    else {
        // callback must be provided like this - Express silently ignores callbacks with cardinality > 3
        app.get('*', (...args) => get_from_mock_endpoint_1.default(...args));
    }
    const server = secureMode
        ? https_1.default.createServer({
            key: fs_1.default.readFileSync(sslServerKey),
            cert: fs_1.default.readFileSync(sslServerCert),
            requestCert: true,
            rejectUnauthorized: false,
            ca: [fs_1.default.readFileSync(process.env.NODE_EXTRA_CA_CERTS)],
        }, app)
        : app;
    server
        .listen(port, () => {
        const nodeVersion = process.versions.node;
        const major = parseInt(nodeVersion.split('.')[0], 10);
        if (major < 10) {
            console.log(chalk_1.default.red(`WARNING! Current Node.js version is ${nodeVersion}. Version 10.x.x or higher required.`));
        }
        console.log(`App running in ${secureMode ? chalk_1.default.green.bold('secure') : chalk_1.default.red.bold('insecure')} mode.`);
        console.log(`Docs at ${chalk_1.default.cyan.bold.underline(`${secureMode ? 'https' : 'http'}://localhost:${port}`)}.`);
        console.log(`Press ${chalk_1.default.cyan.bold('Ctrl + C')} to stop server.`);
        if (reportOutputs.reportsDir) {
            if (!fs_1.default.existsSync(logs_1.reportsDir)) {
                fs_1.default.mkdirSync(logs_1.reportsDir, { recursive: true });
            }
            fs_1.default.writeFileSync(logs_1.reportPath, JSON.stringify({ logs: logs_1.logs }), 'utf-8'); // empty logs array
            console.log(`Logs from this session will be available at ${chalk_1.default.cyan.bold(logs_1.reportPath)}.`);
        }
    });
};
exports.default = {
    start,
};
