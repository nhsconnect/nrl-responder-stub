"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
/**
* reverse lookup (name => code, as opposed to code => name
* as in `http.STATUS_CODES`)
*/
const httpStatus = {};
Object.entries(http_1.default.STATUS_CODES).forEach(([statusCode, message]) => {
    if (message) {
        httpStatus[message.replace(/[^a-z]/gi, '')] = +statusCode;
    }
});
exports.default = httpStatus;
