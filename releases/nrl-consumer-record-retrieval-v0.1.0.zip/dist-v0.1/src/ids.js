"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const IdGenerator = function* (startVal) {
    let i = startVal;
    while (true)
        yield i++;
};
const IdIncrementer = (startVal) => {
    const idGenerator = IdGenerator(startVal);
    return () => idGenerator.next().value;
};
exports.IdIncrementer = IdIncrementer;
const globalId = IdIncrementer(1);
exports.globalId = globalId;
