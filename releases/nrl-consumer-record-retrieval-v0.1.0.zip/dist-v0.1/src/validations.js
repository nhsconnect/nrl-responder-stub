"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Validation {
    constructor(validationId, description, request, response) {
        this.validationId = validationId;
        this.description = description;
        this.request = request;
        this.response = response;
        this.hasRun = false;
    }
    setOutcome(success, details) {
        this.hasRun = true;
        this.success = success;
        this.details = details;
        return this;
    }
    setFailureState(newFailureState) {
        this.setOutcome(!newFailureState, newFailureState || undefined);
        return this;
    }
}
class Validations {
    constructor(request, response) {
        this.request = request;
        this.response = response;
        this._validationList = [];
    }
    add(validationId, description) {
        if (this._find(validationId)) {
            throw new Error(`Duplicate validationId: ${validationId}`);
        }
        const validation = new Validation(validationId, description, this.request, this.response);
        this._validationList.push(validation);
        return validation;
    }
    _find(validationId) {
        return this._validationList.find(validation => validationId === validation.validationId);
    }
    find(validationId) {
        const validation = this._find(validationId);
        if (!validation) {
            throw new Error(`validationId not found: ${validationId}`);
        }
        return validation;
    }
    list() {
        return this._validationList;
    }
    listSerializable() {
        // Exclude circular structures to prevent `TypeError: Converting circular structure to JSON`
        return this._validationList.map(({ validationId, description, hasRun, success, details }) => ({
            validationId,
            description,
            hasRun,
            success,
            details,
        }));
    }
}
exports.default = Validations;
