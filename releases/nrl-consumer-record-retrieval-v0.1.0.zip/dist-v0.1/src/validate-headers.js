"use strict";
/**
 * Runs validations on required headers/header formats
 *
 * Parsing and validation of the JWT in the `Authorization` header is delegated to
 * `./validate-jwt`.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const validate_jwt_1 = __importDefault(require("./validate-jwt"));
const pattern_matchers_1 = require("./pattern-matchers");
const ids_1 = require("./ids");
const VALIDATION_IDS = {
    missingHeaders: `${ids_1.globalId()}`,
    interactionID: `${ids_1.globalId()}`,
    traceId: `${ids_1.globalId()}`,
    asidHeaders: `${ids_1.globalId()}`,
    authHeader: `${ids_1.globalId()}`,
};
exports.default = (validations) => {
    // Ssp-TraceID  	    Consumer’s TraceID (i.e. GUID/UUID)
    // Ssp-From	            Consumer’s ASID
    // Ssp-To       	    Provider’s ASID
    // Ssp-InteractionID	Spine’s InteractionID.
    //                      The interaction ID for retrieving a record referenced in an NRL pointer is specific to the NRL service and is as follows:
    //                      urn:nhs:names:services:nrl:DocumentReference.content.read
    const requiredHeaders = ['Ssp-TraceID', 'Ssp-From', 'Ssp-To', 'Ssp-InteractionID', 'Authorization'];
    const asidHeaders = ['Ssp-From', 'Ssp-To'];
    const interactionIdCorrectVal = 'urn:nhs:names:services:nrl:DocumentReference.content.read';
    validations.add(VALIDATION_IDS.missingHeaders, `Headers [ ${requiredHeaders.join(', ')} ] must all be present`);
    validations.add(VALIDATION_IDS.interactionID, `The Ssp-InteractionID header must have the value "${interactionIdCorrectVal}"`);
    validations.add(VALIDATION_IDS.traceId, 'The Ssp-TraceID header must be a UUID in the format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx (where each x is a hex digit)');
    validations.add(VALIDATION_IDS.asidHeaders, `Headers [ ${asidHeaders.join(', ')} ] must be ASIDs consisting of 12 digits`);
    validations.add(VALIDATION_IDS.authHeader, 'The Authorization header must start with "Bearer "');
    const { request } = validations;
    const { headers } = request;
    const missingHeaders = requiredHeaders.filter(h => !headers[h.toLowerCase()]);
    validations.find(VALIDATION_IDS.missingHeaders)
        .setFailureState(missingHeaders.length
        &&
            `The following required headers are missing or empty: [ ${missingHeaders.join(', ')} ]`);
    validations.find(VALIDATION_IDS.interactionID)
        .setFailureState(headers['ssp-interactionid'] !== interactionIdCorrectVal
        &&
            `The Ssp-InteractionID header has the value ${JSON.stringify(headers['ssp-interactionid'])}`);
    validations.find(VALIDATION_IDS.traceId)
        .setFailureState(!pattern_matchers_1.isUuid(typeof headers['ssp-traceid'] === 'string' ? headers['ssp-traceid'] : '')
        &&
            `The Ssp-TraceID header has the value ${JSON.stringify(headers['ssp-traceid'])}`);
    const incorrectAsidHeaders = asidHeaders.filter(h => {
        const header = headers[h.toLowerCase()];
        return !pattern_matchers_1.isAsid(typeof header === 'string' ? header : '');
    });
    validations.find(VALIDATION_IDS.asidHeaders)
        .setFailureState(incorrectAsidHeaders.length
        &&
            `The [ ${incorrectAsidHeaders.join(', ')} ] headers are not ASIDs consisting of 12 digits`);
    const authHeader = typeof headers.authorization === 'string' ? headers.authorization : '';
    validations.find(VALIDATION_IDS.authHeader)
        .setFailureState(!authHeader.startsWith('Bearer ')
        &&
            `The Authorization header does not start with "Bearer "`);
    validate_jwt_1.default(validations, authHeader.replace(/^Bearer /, ''));
};
