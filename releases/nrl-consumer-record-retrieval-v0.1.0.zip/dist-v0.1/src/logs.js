"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const config_1 = __importDefault(require("./config"));
const reportFileName = `${new Date().toISOString().slice(0, -5).replace(/\D/g, '-')}.json`;
exports.reportFileName = reportFileName;
const reportsDir = path_1.default.join(__dirname, 'reports');
exports.reportsDir = reportsDir;
const reportPath = path_1.default.join(reportsDir, reportFileName);
exports.reportPath = reportPath;
const logs = [];
exports.logs = logs;
const guided_test_plan_1 = __importDefault(require("./guided-test-plan"));
const { reportOutputs } = config_1.default;
const meta = { config: config_1.default };
exports.meta = meta;
if (config_1.default.mode === 'guided') {
    meta.guidedTestPlan = guided_test_plan_1.default;
}
const writeLog = (entry) => {
    logs.push(entry);
    if (reportOutputs.stdout) {
        console.log(JSON.parse(JSON.stringify(entry)));
    }
    if (reportOutputs.reportsDir) {
        fs_1.default.writeFileSync(reportPath, JSON.stringify({ meta, logs }), 'utf-8');
    }
};
exports.writeLog = writeLog;
const buildLogEntry = (request, response, validations) => {
    var _a;
    const { headers, httpVersion, method, path, body: requestBody } = request;
    const { statusCode, body: responseBody } = response;
    const entry = {
        request: { headers, httpVersion, method, path, body: requestBody },
        response: { statusCode, headers: response.getHeaders(), body: responseBody },
        validations: (_a = validations) === null || _a === void 0 ? void 0 : _a.listSerializable()
    };
    if (method === 'GET')
        delete entry.request.body;
    return entry;
};
exports.buildLogEntry = buildLogEntry;
